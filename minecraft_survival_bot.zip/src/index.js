import fs from "node:fs";
import path from "node:path";
import mineflayer from "mineflayer";
import { pathfinder, Movements, goals } from "mineflayer-pathfinder";
import { Vec3 } from "vec3";

const DATA_DIR = path.resolve("data");
const MEMORY_FILE = path.join(DATA_DIR, "memory.json");
fs.mkdirSync(DATA_DIR, { recursive: true });

const cfg = {
  host: process.env.MC_HOST || "PUT_SERVER_IP_HERE",
  port: Number(process.env.MC_PORT || 25565),
  username: process.env.MC_USERNAME || "SurvivalHelper",
  auth: process.env.MC_AUTH || "offline",
  radiusChunks: Number(process.env.HOME_RADIUS_CHUNKS || 16)
};

const BLOCKS = {
  logs: ["oak_log","birch_log","spruce_log","jungle_log","acacia_log","dark_oak_log","mangrove_log","cherry_log"],
  leaves: ["oak_leaves","birch_leaves","spruce_leaves","jungle_leaves","acacia_leaves","dark_oak_leaves","mangrove_leaves","cherry_leaves"],
  saplings: ["oak_sapling","birch_sapling","spruce_sapling","jungle_sapling","acacia_sapling","dark_oak_sapling","mangrove_propagule","cherry_sapling"],
  crops: ["wheat","carrots","potatoes","beetroots"]
};

let memory = loadMemory();
let bot;
let reconnectTimer;

function loadMemory() {
  try { return JSON.parse(fs.readFileSync(MEMORY_FILE, "utf8")); }
  catch {
    return {
      home: null,
      bed: null,
      farm: null,
      water: null,
      treeFarm: [],
      death: null,
      known: { trees: [], water: [], safe: [], dangerous: [] },
      learning: { successes: {}, failures: {}, routeScores: {} }
    };
  }
}
function saveMemory() {
  fs.writeFileSync(MEMORY_FILE, JSON.stringify(memory, null, 2));
}
function posObj(p) { return p ? {x:p.x,y:p.y,z:p.z} : null; }
function dist(a,b) {
  return Math.sqrt((a.x-b.x)**2 + (a.y-b.y)**2 + (a.z-b.z)**2);
}
function insideHome(p) {
  if (!memory.home) return true;
  return Math.abs(p.x-memory.home.x) <= cfg.radiusChunks*16 &&
         Math.abs(p.z-memory.home.z) <= cfg.radiusChunks*16;
}
function remember(type, p) {
  if (!p) return;
  const arr = memory.known[type];
  if (!arr) return;
  if (!arr.some(q => dist(q,p) < 4)) arr.push(posObj(p));
  if (arr.length > 100) arr.shift();
  saveMemory();
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

function findBlock(names, maxDistance=48) {
  if (!bot?.entity) return null;
  const set = new Set(names);
  return bot.findBlock({
    matching: b => b && set.has(b.name),
    maxDistance
  });
}

async function walkTo(pos, range=2) {
  if (!insideHome(pos)) return false;
  const mcData = bot.registry;
  const movements = new Movements(bot, mcData);
  movements.canDig = false;
  movements.allow1by1towers = false;
  bot.pathfinder.setMovements(movements);
  try {
    await bot.pathfinder.goto(new goals.GoalNear(pos.x,pos.y,pos.z,range));
    return true;
  } catch {
    return false;
  }
}

async function equipBest(names) {
  for (const n of names) {
    const item = bot.inventory.items().find(i => i.name === n);
    if (item) { try { await bot.equip(item, "hand"); return true; } catch {} }
  }
  return false;
}

async function craftItem(name, count=1) {
  const recipe = bot.recipesFor(bot.registry.itemsByName[name]?.id, null, count, null)[0];
  if (!recipe) return false;
  try { await bot.craft(recipe, count, null); return true; } catch { return false; }
}

async function collectNearbyDrops() {
  for (const e of Object.values(bot.entities)) {
    if (e.type === "object" && e.position && dist(bot.entity.position,e.position) < 12 && insideHome(e.position)) {
      await walkTo(e.position, 1);
    }
  }
}

async function gatherSeeds() {
  const grass = findBlock(["short_grass","grass"], 32);
  if (!grass) return false;
  if (!await walkTo(grass.position, 2)) return false;
  await bot.dig(grass, true);
  await sleep(500);
  await collectNearbyDrops();
  return bot.inventory.items().some(i => i.name === "wheat_seeds");
}

async function findWater() {
  if (memory.water) return new Vec3(memory.water.x,memory.water.y,memory.water.z);
  const b = findBlock(["water"], 64);
  if (b) {
    memory.water = posObj(b.position);
    remember("water", b.position);
    saveMemory();
    return b.position;
  }
  return null;
}

async function makeFarm() {
  if (memory.farm) return true;
  const water = await findWater();
  if (!water) return false;

  const targets = [];
  for (let dx=-3; dx<=3; dx++) for (let dz=-3; dz<=3; dz++) {
    if (Math.abs(dx)+Math.abs(dz) < 1) continue;
    const p = water.offset(dx,0,dz);
    if (insideHome(p)) targets.push(p);
  }
  for (const p of targets.slice(0, 16)) {
    const block = bot.blockAt(p);
    if (!block || !block.name.includes("dirt")) continue;
    await walkTo(p, 1);
    if (await equipBest(["wooden_hoe","stone_hoe","iron_hoe"])) {
      try { await bot.activateBlock(block); } catch {}
    }
  }
  memory.farm = posObj(water.offset(2,0,2));
  saveMemory();
  return true;
}

async function plantSeeds() {
  const seed = bot.inventory.items().find(i => i.name === "wheat_seeds");
  if (!seed) return false;
  const farmland = findBlock(["farmland"], 32);
  if (!farmland) return false;
  if (!await walkTo(farmland.position, 2)) return false;
  try {
    await bot.equip(seed, "hand");
    await bot.activateBlock(farmland);
    return true;
  } catch { return false; }
}

async function harvestCrop() {
  const crop = findBlock(BLOCKS.crops, 40);
  if (!crop) return false;
  if (!await walkTo(crop.position, 2)) return false;
  try {
    await bot.dig(crop, true);
    await sleep(300);
    await plantSeeds();
    return true;
  } catch { return false; }
}

async function harvestTree() {
  const log = findBlock(BLOCKS.logs, 64);
  if (!log) return false;
  if (!insideHome(log.position)) return false;
  remember("trees", log.position);
  if (!await walkTo(log.position, 2)) return false;

  let count = 0;
  while (count < 40) {
    const b = findBlock(BLOCKS.logs, 6);
    if (!b) break;
    try { await equipBest(["wooden_axe","stone_axe","iron_axe"]); await bot.dig(b, true); }
    catch { break; }
    count++;
    await sleep(150);
  }

  await sleep(800);
  await collectNearbyDrops();
  await replantTree();
  return true;
}

async function replantTree() {
  const sap = bot.inventory.items().find(i => BLOCKS.saplings.includes(i.name));
  if (!sap) return false;

  // Keep a small reserve.
  if (sap.count < 1) return false;

  const base = memory.treeFarm.length
    ? new Vec3(memory.treeFarm[0].x,memory.treeFarm[0].y,memory.treeFarm[0].z)
    : (memory.home ? new Vec3(memory.home.x,memory.home.y,memory.home.z) : bot.entity.position);

  for (let dx=-6; dx<=6; dx+=3) for (let dz=-6; dz<=6; dz+=3) {
    const p = base.offset(dx,0,dz);
    if (!insideHome(p)) continue;
    const soil = bot.blockAt(p);
    const above = bot.blockAt(p.offset(0,1,0));
    if (soil && ["dirt","grass_block"].includes(soil.name) && above?.name === "air") {
      try {
        await walkTo(p, 1);
        await bot.equip(sap, "hand");
        await bot.placeBlock(soil, new Vec3(0,1,0));
        memory.treeFarm.push(posObj(p));
        memory.treeFarm = memory.treeFarm.slice(-30);
        saveMemory();
        return true;
      } catch {}
    }
  }
  return false;
}

async function gatherWoodAndCraft() {
  const log = findBlock(BLOCKS.logs, 64);
  if (!log) return false;
  await harvestTree();

  const logs = bot.inventory.items().filter(i => BLOCKS.logs.includes(i.name));
  if (logs.length) {
    const planks = logs[0].name.replace("_log","_planks");
    await craftItem(planks, Math.min(8, logs[0].count));
  }
  await craftItem("stick", 4);
  await craftItem("crafting_table", 1);
  await craftItem("wooden_sword", 1);
  await craftItem("wooden_axe", 1);
  await craftItem("wooden_hoe", 1);
  return true;
}

function needsFood() {
  return bot.food !== undefined && bot.food <= 10;
}

function hasBasicTool(name) {
  return bot.inventory.items().some(i => i.name === name);
}

async function eatFood() {
  const foods = ["bread","cooked_beef","cooked_porkchop","cooked_mutton","cooked_chicken","apple","carrot","potato"];
  const item = bot.inventory.items().find(i => foods.includes(i.name));
  if (!item) return false;
  try { await bot.equip(item, "hand"); await bot.consume(); return true; } catch { return false; }
}

async function brainTick() {
  if (!bot?.entity) return;

  if (!memory.home) {
    memory.home = posObj(bot.entity.position);
    saveMemory();
  }

  // Hard safety boundary.
  if (!insideHome(bot.entity.position)) {
    await walkTo(new Vec3(memory.home.x,memory.home.y,memory.home.z), 3);
    return;
  }

  if (needsFood()) {
    if (await eatFood()) return;
  }

  // Harvest ripe crops whenever one is nearby.
  if (await harvestCrop()) {
    memory.learning.successes.harvestCrop = (memory.learning.successes.harvestCrop||0)+1;
    saveMemory();
    return;
  }

  // Keep the farm supplied with seeds.
  if (!bot.inventory.items().some(i=>i.name==="wheat_seeds")) {
    if (await gatherSeeds()) return;
  }

  // Make/maintain the farm.
  if (!memory.farm) {
    if (await makeFarm()) return;
  }

  // Plant available seeds.
  if (await plantSeeds()) return;

  // Maintain tree supply.
  if (!hasBasicTool("wooden_axe") && !hasBasicTool("stone_axe")) {
    if (await gatherWoodAndCraft()) return;
  }

  // If low on wood, harvest a tree and replant it.
  const woodCount = bot.inventory.items()
    .filter(i=>BLOCKS.logs.includes(i.name))
    .reduce((n,i)=>n+i.count,0);
  if (woodCount < 8) {
    if (await gatherWoodAndCraft()) return;
  }

  await collectNearbyDrops();
  await sleep(1200 + Math.random()*1800);
}

function startBot() {
  bot = mineflayer.createBot({
    host: cfg.host,
    port: cfg.port,
    username: cfg.username,
    auth: cfg.auth,
    version: false
  });

  bot.loadPlugin(pathfinder);

  bot.once("spawn", async () => {
    console.log(`Connected as ${bot.username}`);
    if (!memory.home) memory.home = posObj(bot.entity.position);
    saveMemory();

    setInterval(() => brainTick().catch(e => console.log("brain:",e.message)), 2500);
  });

  bot.on("death", () => {
    memory.death = posObj(bot.entity.position);
    saveMemory();
    console.log("Death recorded:", memory.death);
  });

  bot.on("kicked", reason => console.log("Kicked:", reason));
  bot.on("error", err => console.log("Error:", err.message));
  bot.on("end", () => {
    console.log("Disconnected; reconnecting in 10 seconds...");
    clearTimeout(reconnectTimer);
    reconnectTimer = setTimeout(startBot, 10000);
  });
}

if (cfg.host.includes("PUT_SERVER")) {
  console.log("Edit .env first: set MC_HOST and MC_PORT.");
} else {
  startBot();
}

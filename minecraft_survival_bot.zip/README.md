# Minecraft Autonomous Survival Bot

A Mineflayer-based survival/farming bot scaffold.

## Current architecture

- 16-chunk configurable home radius (256 blocks from the home point).
- Persistent memory in `data/memory.json`.
- Priority/task brain.
- Safe movement with mineflayer-pathfinder.
- Finds water and makes a small farmland area beside it.
- Searches grass for seeds.
- Searches for nearby trees, harvests logs and collects saplings.
- Replants saplings in a simple tree farm.
- Crafts basic wooden tools.
- Plants/harvests wheat when possible.
- Keeps a remembered home/bed/farm/death position.
- Basic stuck detection and reconnect loop.
- Does not sprint by default.
- Learning is deliberately bounded: it records successful/failed observations rather than modifying its own source code.

## Setup

1. Install Node.js 18+.
2. Copy `.env.example` to `.env`.
3. Put your Minecraft server IP and port in `.env`.
4. Run:
   npm install
   npm start

For an Aternos server, the bot process must run on a machine/host that remains online. This project does not attempt to bypass Aternos or anti-cheat restrictions.

## Important

Test this on a server/world you control. The bot is a starting framework, not a finished human-level Minecraft player. Minecraft versions and server plugins can change which Mineflayer APIs work.
